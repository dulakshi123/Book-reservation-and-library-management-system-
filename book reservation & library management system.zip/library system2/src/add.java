
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Acer
 */
public class add extends javax.swing.JInternalFrame {

    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    
    public add() {
        initComponents();
        tableload();
    }

    public void tableload(){
    
    try{
    con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library","root","");
   String query = "SELECT `bookname`,  `bookcetogery`, `bookcount`FROM `bookdetails` ";
   pst = con.prepareStatement(query);
   rs = pst.executeQuery();
    jTable1.setModel(DbUtils.resultSetToTableModel(rs));
   }catch(Exception e){
   
   
   
   }
    
    }
    
     public void search(){
   
    String srch = searchbox.getText();
    
       try {
           String query = "SELECT  `bookname`,  `bookcetogery`,`bookcount` FROM `bookdetails` WHERE bookname LIKE'%"+srch+"%'";
           pst= con.prepareStatement(query);
           rs= pst.executeQuery();
           jTable1.setModel(DbUtils.resultSetToTableModel(rs));
       } catch (Exception e) {
           JOptionPane.showMessageDialog(null,e);
       }
   
   }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        searchbox = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        countbox = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        searchbox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchboxActionPerformed(evt);
            }
        });
        getContentPane().add(searchbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, 280, 50));

        jButton1.setBackground(new java.awt.Color(102, 0, 0));
        jButton1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jButton1.setText("SEARCH");
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 220, 190, 50));

        jTable1.setBackground(new java.awt.Color(102, 102, 102));
        jTable1.setForeground(new java.awt.Color(255, 153, 0));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "BOOK NAME", "BOOK CETOGERY", "BOOK COUNTl"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 160, -1, 300));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel2.setText("BOOK CASE");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, 150, 40));

        countbox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                countboxActionPerformed(evt);
            }
        });
        getContentPane().add(countbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 300, 310, 50));

        jButton2.setBackground(new java.awt.Color(102, 0, 0));
        jButton2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jButton2.setText("UPDATE");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 370, 190, 50));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/OROJINAL2.jpeg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1100, 830));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void searchboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchboxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchboxActionPerformed

    private void countboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_countboxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_countboxActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        
        
         int r = jTable1.getSelectedRow();
       ///String id = jTable1.getValueAt(r,0).toString();
       String name= jTable1.getValueAt(r,1).toString(); 
         // String authorname= jTable1.getValueAt(r,2).toString(); 
          String bookcetogery= jTable1.getValueAt(r,3).toString(); 
          String bookcount= jTable1.getValueAt(r,4).toString(); 
          //String bookcase= jTable1.getValueAt(r,5).toString(); 
         // String bookprice= jTable1.getValueAt(r,6).toString(); 
       
       
        
        
     //   idbox.setText(id);
      //  namebox.setText(name);
        // authorbox.setText(authorname);
         // cetogerybox.setSelectedItem(bookcetogery);
           countbox.setText(bookcount); 
           //casebox.setText(bookcase);
         //  pricebox.setText(bookprice);
    }//GEN-LAST:event_jTable1MouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        
        try
          {
            /*String value1 = idbox.getText();
            String value2 = namebox.getText();
                String value3= authorbox.getText();
                    String value4 = cetogerybox.getSelectedItem().toString();*/
                        String value5 = countbox.getText();
                            //String value6 = casebox.getText();
                                //String value7 = pricebox.getText();
            
            
            String query = " UPDATE `bookdetails` SET `bookcount`='"+value5+"'";
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/library","root","");
            pst=con.prepareStatement(query);
            pst.execute();
            JOptionPane.showMessageDialog(null,"Update successful" );
            tableload();
          }catch(Exception e)
          {
             JOptionPane.showMessageDialog(null,e ); 
          } 
        
    }//GEN-LAST:event_jButton2ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField countbox;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField searchbox;
    // End of variables declaration//GEN-END:variables
}
